<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;
use App\Event;
use Session;

class EventRegisterController extends Controller
{
    
   /* public function get_id(Request $request) {
       $event_id = $request->event_id
       echo $event_id;
    }*/

    public function store() {




    echo $_POST;



}
