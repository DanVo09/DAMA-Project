@include('header')

<input type="email" id="email" name="email">
<input type="submit" value="Send Password Recovery">







@include('footer')