<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;
use App\Event;
use Session

class MyEventsController extends Controller
{
    //public function index() {}

    public function store() {
        //request('event_title');
        //request('event_price');
        //request('event_date');
        //request('event_description');

        

        //



    }
}
